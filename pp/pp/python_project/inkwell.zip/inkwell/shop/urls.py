# YourAppName/urls.py

from django.urls import path
from .views import register_user, register_owner, add_product

urlpatterns = [
    path('user', register_user, name='user_registration'),
    path('owner', register_owner, name='owner_registration'),
    path('addproduct', add_product, name='add_product'),
]
