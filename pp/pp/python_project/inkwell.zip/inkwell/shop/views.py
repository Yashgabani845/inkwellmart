from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import UserRegistrationForm,OwnerRegistrationForm,ProductForm

def Home(request):
    return render(request,"index.html")
def abc(request):
    return render(request,"abc.html")
def calc(request):
    return render(request,"result.html")
def aboutUs(request):
    return HttpResponse("welcome to staionary shop")

def userForm(request):
    fn=userForm(request)
    data={'form':fn}
    try:
        if request.method=="POST":
            n1=int(request.POST.get('name1'))
            n2=int(request.POST.get('num2'))
            data={
                'form':fn,
                'output':n1+n2
            }
    except:
        pass
    return render(request,"form.html",data)

def register_user(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  
    else:
        form = UserRegistrationForm()

    return render(request, 'user_registration.html', {'form': form})

def register_owner(request):
    if request.method == 'POST':
        form = OwnerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login') 
    else:
        form = OwnerRegistrationForm()

    return render(request, 'owner_registration.html', {'form': form})

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.save()
            return redirect('product_list') 
    else:
        form = ProductForm()

    return render(request, 'add_product.html', {'form': form})